-- SQL queries for Medical Billing Claim Analysis
-- Top 5 denial reasons
SELECT Denial_Reason, COUNT(*) AS Total_Denials
FROM claims
WHERE Claim_Status='Denied'
GROUP BY Denial_Reason
ORDER BY Total_Denials DESC
LIMIT 5;

-- Insurance provider with highest average SLA days
SELECT Insurance_Provider, AVG(SLA_Days) AS Avg_SLA_Days
FROM claims
GROUP BY Insurance_Provider
ORDER BY Avg_SLA_Days DESC;

-- Revenue loss from denied claims
SELECT SUM(Billed_Amount - Paid_Amount) AS Revenue_Loss
FROM claims
WHERE Claim_Status='Denied';

-- Monthly denial rate
SELECT STRFTIME('%Y-%m', Date_of_Service) AS year_month,
       SUM(CASE WHEN Claim_Status='Denied' THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS denial_rate
FROM claims
GROUP BY year_month
ORDER BY year_month;

-- Top CPT codes by volume and denial rate
SELECT CPT_Code,
       COUNT(*) AS volume,
       SUM(CASE WHEN Claim_Status='Denied' THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS denial_rate
FROM claims
GROUP BY CPT_Code
ORDER BY volume DESC;